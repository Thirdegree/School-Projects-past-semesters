package cse360assign1;

/** Assignment 1, CSE 360 Intro to Software Engineering
 * 
 * @author Joel Christiansen
 * @version Jan 22, 2016
 */

public class OrderedIntList {
	
	
	
	private int[] array;  // array
    private int counter = 0; // counter


    /** A list of Integers in ascending order, containing 10 values. 
	 * 
	 */
    OrderedIntList()
    {
        array = new int[10];
    }

    
    /** Inserts a non-duplicate value into the list.
     * 
     * @param value	The value to be inserted.
     */
    public void insert(int value) {
        int insertAt = 0; 
        
        //Finds the location the new value should be inserted
        for (int index = 0; index < counter; index++) {
            if (value > array[ index ]) {
                insertAt++;
            } else {
                continue;
            }
        }

        
        if (array[ insertAt ] != value) {
        	//shifts the appropriate values in the array.
        	for (int index = counter; index > insertAt; index--) { 
        		if (index < 10) {
        			array[ index ] = array[ index - 1 ];
        		}
        	}
        	
        	array[ insertAt ] = value;
        	if (counter < 10) {
        		counter++;
        	}
        }
    }

    /**
     * Stylized print command.
     */
    public void print() {
    	for (int index = 0; index < counter; index++) {
            if (index % 5 == 0) {
                System.out.println();
            }
            System.out.print(array[ index ] + "\t");  
        }
    }
}
