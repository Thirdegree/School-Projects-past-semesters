#ifndef PROJECT2_H
#define PROJECT2_H


void allocate(struct heapEntry *myHeap, char *mem, struct symbolTableEntry *table, std::string varName, int var, int len, std::string value); 

void add(char *mem, struct symbolTableEntry *table, std::string var, int x);
void add(char *mem, struct symbolTableEntry *table, std::string var, std::string v); 

void myStrcat(char *mem, struct symbolTableEntry *table, std::string var, std::string v); 

void print(char *mem, struct symbolTableEntry *table, std::string var); 

void myFree(char *mem, struct symbolTableEntry *table, struct heapEntry *myHeap, std::string var); 

void map(char *mem); 

void compact(char *mem, struct heapEntry *myHeap); 

void insert(struct heapEntry *myHeap, char *mem, struct symbolTableEntry *table, std::string varName, std::string value);
#endif
