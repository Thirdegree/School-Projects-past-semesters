#ifndef HELPERS_H
#define HELPERS_H

bool sortByValue(struct team_stats &team1, struct team_stats &team2, std::string field, std::string order);

#endif