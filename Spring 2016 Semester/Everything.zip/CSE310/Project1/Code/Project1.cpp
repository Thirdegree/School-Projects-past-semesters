#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "defns.cc"
#include "helpers.h"
//forward declarations
void qsortHelper(struct team_stats *statList, int year, std::string field, std::string order, int left, int right);
int partition(struct team_stats *statList, int year, std::string field, std::string order, int left, int right);

void bsort(struct team_stats *statList, int year, std::string field, std::string order) {

    int swap;

    for (int ii = 1; ii < NO_TEAMS; ii++){
        swap = 1;
        struct team_stats temp;

        for (int jj = 0; jj < (NO_TEAMS - 1) && swap == 1; jj++) {
            if ( sortByValue(statList[jj], statList[jj+1], field, order)) {
                temp = statList[jj];
                statList[jj] = statList[jj+1];
                statList[jj+1] = temp;
                
            } else {
                swap = 0;
            }
        }
    }

    return;
}

void qsort(struct team_stats *statList, int year, std::string field, std::string order) {
    return qsortHelper(statList, year, field, order, 0, NO_TEAMS-1); 
}

void qsortHelper(struct team_stats *statList, int year, std::string field, std::string order, int left, int right) {
    if (left<right){
        int pivotIndex = partition(statList, year, field, order, left, right);
        qsortHelper(statList, year, field, order, left, pivotIndex-1);
        qsortHelper(statList, year, field, order, pivotIndex, right);
    }

    return;
}

int partition(struct team_stats *statList, int year, std::string field, std::string order, int left, int right) {
    struct team_stats pivot=statList[left];
    struct team_stats temp;
    int pivotIndex = left;

    for(int i = left+1; i<right; i++) {
        if (sortByValue(pivot, statList[i],field, order) && pivotIndex != i) {
            temp = statList[pivotIndex];
            statList[pivotIndex] = statList[i];
            statList[i] = temp;

            pivotIndex++;
        }
    }
    temp = statList[left];
    statList[left] = statList[pivotIndex];
    statList[pivotIndex] = temp;

    return pivotIndex;

}

struct team_stats bfind(team_stats &statList, int year, std::string field, std::string item) {
    if (item.compare("max") == 0) {
        bsort(&statList, year, field, "decr");
    }

    return (&statList)[0];
}

int main()
{
    struct team_stats statList[ NO_TEAMS ];
    bsort(statList, 5, "hello", "goodbye");
    struct team_stats test = bfind(*statList, 5, "hello", "max");
    printf("Hello\n");
    return 0;
}

