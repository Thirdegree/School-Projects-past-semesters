#include "q.h"

struct Queue *ReadyQ;
TCB_t *Curr_Thread;

void start_thread(void (*function)(void)) {
    struct Queue *t = NewItem();
    void *stack = malloc(8192);
    struct TCB_t *thread = malloc(sizeof(TCB_t));
    init_TCB(thread, function, stack, 8192);
    t->payload = thread;
    AddQueue(ReadyQ, t);
}

void run() {
    Curr_Thread = DelQueue(ReadyQ)->payload;
    ucontext_t parent;
    getcontext(&parent);
    swapcontext(&parent, &(Curr_Thread->context));
}

void yield() {
    struct Queue *temp = NewItem();
    temp->payload = Curr_Thread;
    AddQueue(ReadyQ, temp);
    TCB_t *Prev_thread = Curr_Thread;
    Curr_Thread = DelQueue(ReadyQ)->payload;
    swapcontext(&(Prev_thread->context), &(Curr_Thread->context));
}
