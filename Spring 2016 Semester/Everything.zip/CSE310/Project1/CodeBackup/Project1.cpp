#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "defns.cc"
#include "helpers.h"


void bsort(struct team_stats *statList, int year, std::string field, std::string order) {

    int swap;

    for (int ii = 1; ii < NO_TEAMS; ii++){
        swap = 0;
        struct team_stats temp;

        for (int jj = 0; jj < (NO_TEAMS - 1); jj++) {
            if ( sortByValue(statList[jj], statList[jj+1], field, order) ) {
                temp = statList[jj];
                statList[jj] = statList[jj+1];
                statList[jj+1] = temp;
                swap = 1;
            }
        }
    }

    return;
}

void qsort(struct team_stats *statList, int year, std::string field, std::string order) {
    
}

struct team_stats bfind(team_stats &statList, int year, std::string field, std::string item) {
    if (item.compare("max") == 0) {
        bsort(&statList, year, field, "decr");
    }

    return (&statList)[0];
}

int main()
{
    struct team_stats statList[ NO_TEAMS ];
    bsort(statList, 5, "hello", "goodbye");
    struct team_stats test = bfind(*statList, 5, "hello", "max");
    printf("Hello\n");
    return 0;
}

