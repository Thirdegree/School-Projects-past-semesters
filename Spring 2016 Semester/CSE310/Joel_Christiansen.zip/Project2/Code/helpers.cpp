#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sstream>
#include <iostream>
#include "Project2.h"
#include "defns.cc"

void  instructionParser(std::string commandUnparsed, char *mem, struct heapEntry *myHeap, struct symbolTableEntry *table) {
    std::stringstream stream(commandUnparsed);
    std::string command[5] = {"","","","",""};
    int index = 0;
    char c;
    for (int i = 0; i < commandUnparsed.size(); i++) {
        c = stream.get();

        if (c == '"') {
            command[index] += c;
            c = stream.get();
            int j = 0;
            while (c != '"') {
                command[index] += c;
                c = stream.get();
                j++;
            }
            command[index] += c; 

            i += j;
        } else if (c == ' ') {
            index++;
        } else {
            command[index] += c;
        }
    }
    if (command[0].compare(0, 8, "allocate") == 0) {
        if (command[1].compare(0,3,"INT") == 0) {
            allocate(myHeap, mem, table, command[2], 0, 4, command[3]);
        } else if (command[1].compare(0,4, "CHAR") == 0) {
            allocate(myHeap, mem, table, command[2], 1, atoi(command[3].c_str()), command[4]);
        } else if (command[1].compare(0,3, "BST") == 0) {
            allocate(myHeap, mem, table, command[2], BST, 12, command[3]);
        }// char and int taken care of
        return; 
    }
    if (command[0].compare(0, 3, "add") == 0) {
        if (isalpha(command[2].at(0))) {
            add(mem, table, command[1], command[2]);
        } else {
            add(mem, table, command[1], atoi(command[2].c_str()));
        }
        return;
    }
    if (command[0].compare(0, 6, "strcat") == 0) {
        myStrcat(mem, table, command[1], command[2]);
        return;
    }
    if (command[0].compare(0, 5, "print") == 0) {
        print(mem, table, command[1]);
        return;
    }
    if (command[0].compare(0, 4, "free") == 0) {
        myFree(mem, table, myHeap, command[1]);
        return;
    }
    if (command[0].compare(0, 7, "compact") == 0) {
        compact(mem, myHeap);
        return;
    }
    if (command[0].compare(0, 3, "map") == 0) {
        map(mem);
        return;
    }
    if (command[0].compare(0, 6, "insert") == 0) {
        insert(myHeap, mem, table, command[1], command[2]);
    }
    return;
}

int hashSymbol(const char* entry, int t) {
    int total = 0;
    for (int ii = 0; ii < SYMBOL_LENGTH; ii++) {
        if (entry[ii] == STRTERM) {
            return total;
        }
        total += (int) entry[ii];
    }
    return total % t;
}

int probe(struct symbolTableEntry *table, const char* entry, int allocate, int t, size_t len) {
    int symbol = hashSymbol(entry, t); 
    std::cout << len << entry << std::endl;

    int i = 0;
    while (strncmp(table[(symbol + i) % t].symbol, entry, len) != 0 && strncmp(table[(symbol + i) % t].symbol, "root", 4) != 0) {
        i++;
        if (strcmp(table[(symbol + i) % t].symbol, "empty") == 0 && allocate) {
            break;
        }
        if (strcmp(table[(symbol + i) % t].symbol, "deleted") == 0 && allocate) {
            break;
        }
    }
    return (symbol + i) % t;
}

void maxHeapify(struct heapEntry *myHeap, int i, int n) {
    i++; //because maxheapify needs 1-indexed array not 0;
    int l = i*2;
    int r = i*2 + 1;
    int largest = i;
    struct heapEntry temp;
    if (l<=n && myHeap[l-1].blockSize > myHeap[i-1].blockSize) { 
        largest = l;
    } else {
        largest = i;
    }
    if (r<=n and myHeap[r-1].blockSize > myHeap[largest-1].blockSize) {
        largest = r;
    }
    if (largest != i) {
        temp = myHeap[i-1];
        myHeap[i-1] = myHeap[largest-1];
        myHeap[largest-1] = temp;
        maxHeapify(myHeap, largest-1, n);
    }
}
