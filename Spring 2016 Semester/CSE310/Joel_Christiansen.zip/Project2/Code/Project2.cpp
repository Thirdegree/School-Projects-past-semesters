#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <math.h>
#include "defns.cc"
#include "helpers.h"


#define EMPTY (struct symbolTableEntry){"empty",-1,-1,-1}
#define DELETED (struct symbolTableEntry){"deleted",-2,-2,-2}

int n = 0;
int k = 0;
int t = 0;

void map(char*);

int myMalloc(struct heapEntry *myHeap, char *mem, int var, int len, std::string value) {
    if (myHeap[0].blockSize < len) {
        printf("Error: Insufficient memory to allocate variable.\n");
        return 0;
    }
    int newBlockSize = myHeap[0].blockSize - len;
    int newOffset = myHeap[0].offset + len;
    if (var == INT) {
        *((int*) (mem + myHeap[0].offset)) = atoi(value.c_str());
    }
    if (var == CHAR) {
        int i = 1;
        while (value.at(i) != '"') {
            *((char*) mem + myHeap[0].offset + i - 1) = value.at(i);
            i++;
        }
        *((char*) mem + myHeap[0].offset + i - 1) = '\0';
        i++;
        for (i; i < len-1; i++) {
            *((char*) mem + myHeap[0].offset + i - 1) = ' ';
        }
    }
    if (var == BST) {
        ((struct bstNode*) mem + myHeap[0].offset)->key = atoi(value.c_str());
        ((struct bstNode*) mem + myHeap[0].offset)->left = 0;
        ((struct bstNode*) mem + myHeap[0].offset)->right = 0;
    } 
        
    struct heapEntry *newEntry = new heapEntry();
    newEntry->blockSize = newBlockSize;
    newEntry->offset = newOffset;
    myHeap[0] = *newEntry;
    maxHeapify(myHeap, 0, n);

      
    return 1;
}

void allocate(struct heapEntry *myHeap, char *mem, struct symbolTableEntry *table, std::string varName, int var, int len, std::string value) {
    struct symbolTableEntry *newEntry = new symbolTableEntry();
    std::copy(varName.begin(), varName.end(), newEntry->symbol);
    newEntry->type = var;
    newEntry->offset = myHeap[0].offset;
    newEntry->noBytes = len;
    if (myMalloc(myHeap, mem, var, len, value)) {
        int newIndex = probe(table, varName.c_str(),1, t, varName.size());
        table[newIndex] = *newEntry;
    }
    return;

}

void add(char *mem, struct symbolTableEntry *table, std::string var, int x) {
    int index = probe(table, var.c_str(), 0, t, var.size());
    struct symbolTableEntry entry = table[index];
    if (entry.type != INT) {
        std::cout << "Error: LHS of add must be type INT" << std::endl;
        return;
    }
    *((int*) (mem+entry.offset)) = *((int*) (mem+entry.offset)) + x;
    return;
} 

void add(char *mem, struct symbolTableEntry *table, std::string var, std::string v) {
    int index = probe(table, v.c_str(), 0, t, v.size()-1); //-1 to strip newline
    struct symbolTableEntry entry = table[index];
    std::cout << entry.symbol << std::endl;
    if (entry.type != INT) {
        std::cout << "Error: RHS of add must be type INT" << std::endl;
        return;
    }
    int value = *((int*) (mem+entry.offset));
    add(mem, table, var, value);
    return;
}

void myStrcat(char *mem, struct symbolTableEntry *table, std::string var, std::string v) {
    if (v.at(0) != '"') { //IF IT IS A VARIABLE NAME RATHER THAN A LITERALL
        int index = probe(table, v.c_str(), 0, t, v.size()-1); //-1 to strip newline
        int index2 = probe(table, var.c_str(), 0, t, var.size());
        struct symbolTableEntry *varEntry = &table[index2];
        struct symbolTableEntry *vEntry = &table[index];
        int i = 0;
        while (*((char*) (mem + varEntry->offset + i)) != 0) {
            i++;
        }
        int j = 0;
        if (varEntry->noBytes >= vEntry->noBytes + i) { 
            while (*((char*) (mem + vEntry->offset + j)) != '\0') {
                *((char*) (mem + varEntry->offset + i)) = *((char*) (mem + vEntry->offset + j)); //this hurts to even look at.
                i++; 
                j++;
            }
            *((char*) (mem + varEntry->offset + i)) = '\0'; //KEEP AN EYE ON THIS, LIKELY ERROR
        }
    } else { //IF IT'S A LITERALL RATHER THAN A VARIABLE
        int index = probe(table, var.c_str(), 0, t, var.size());
        struct symbolTableEntry *varEntry = &table[index];
        int i = 0;
        while (*((char*) (mem + varEntry->offset + i)) != '\0') {
            i++;
        }
        int j = 0;
        for (j = 0; j < v.size(); j++) {
            *((char*) (mem + varEntry->offset + i)) = v.at(j);
            i++;
        }
        *((char*) (mem + varEntry->offset + i)) = '\0';
    }
    
    return;
}

void insert(struct heapEntry *myHeap, char *mem, struct symbolTableEntry *table, std::string varName, std::string value) {
    int indexRoot = probe(table, varName.c_str(), 0, t, varName.size());
    struct symbolTableEntry entry = table[indexRoot];
    if (strcmp(entry.symbol, "empty") == 0 || strcmp(entry.symbol, "deleted") == 0) {
        return;
    }
    struct bstNode *current = ((struct bstNode*) mem + entry.offset);
    int val = atoi(value.c_str());
    bool found = false;
    while (!found) {
        std::cout << 'a' << std::endl;
        if (val <= current->key && current->left != 0) {
            current = ((struct bstNode*) mem + current->left);
        } else if (val > current->key && current->right != 0) {
            current = ((struct bstNode*) mem + current->right);
        } else {
            found = true;
        }
    }
    if (val <= current->key) {
       current->left = myHeap[0].offset;
    } else {
        current->right = myHeap[0].offset;
    }
    myMalloc(myHeap, mem, BST, 12, value);
    return;
}

void bstPrint(char *mem, int offset) {
    if (((struct bstNode*) mem + offset)->left != 0) {
        bstPrint(mem, ((struct bstNode*) mem + offset)->left);
    }
    std::cout << " " << ((struct bstNode*) mem + offset)->key << " ";
    if (((struct bstNode*) mem + offset)->right != 0) {
        bstPrint(mem, ((struct bstNode*) mem + offset)->right);
    }
}

void print(char *mem, struct symbolTableEntry *table, std::string var) {
    int index = probe(table, var.c_str(), 0, t, var.size());
    struct symbolTableEntry entry = table[index];
    if (entry.type == INT) {
        std::cout << *((int*) (mem+entry.offset)) << std::endl;
    }
    if (entry.type == CHAR) {
        int i = 0;
        char temp = ' ';
        while (temp != '\0') {
            temp = *((char*) (mem+entry.offset+i));
            std::cout << temp;
            i++;
        }
        std::cout << std::endl;
    }
    if (entry.type == BST) {
        std::cout << "[";
        bstPrint(mem, entry.offset);
        std::cout << "]" << std::endl;
    }
    return;
}

void bstFree(char *mem, int offset, struct heapEntry *myHeap) {
    if (((struct bstNode*) mem + offset)->left != 0) {
        bstFree(mem, ((struct bstNode*) mem + offset)->left, myHeap);
    }
    if (((struct bstNode*) mem + offset)->right != 0) {
        bstFree(mem,((struct bstNode*) mem + offset)->right, myHeap);
    }
    struct heapEntry *temp = (struct heapEntry*) malloc(sizeof(struct heapEntry*));
    temp->offset = offset;
    temp->blockSize = 12;
    n++;
    myHeap[n] = *temp;
    for (int i = 0; i < 12; i++) {
        *(mem + offset + i) = '-';
    }
}

void myFree(char *mem, struct symbolTableEntry *table, struct heapEntry *myHeap, std::string var) {
    struct heapEntry *temp = (struct heapEntry*) malloc(sizeof(struct heapEntry*));
    int index = probe(table, var.c_str(), 0, t, var.size()-1); //-1 to strip newline
    struct symbolTableEntry entry = table[index];
    temp->offset = entry.offset;
    temp->blockSize = entry.noBytes;
    n++;
    myHeap[n] = *temp;
    if (entry.type == BST) {
        if (((struct bstNode*) mem + entry.offset)->left != 0) {
            bstFree(mem, ((struct bstNode*) mem + entry.offset)->left, myHeap);
        }
        if (((struct bstNode*) mem + entry.offset)->right != 0) {
            bstFree(mem,((struct bstNode*) mem + entry.offset)->right, myHeap);
        }
    } 
    for (int i = 0; i < temp->blockSize;i++) {
        *(mem+entry.offset + i) = '-';
    }
    return;
}

void compact(char *mem, struct heapEntry *myHeap) {
    int accum = 0;
    n = 0;
    int tempOffset = 0;
    int tempSize = 0;
    for (int i = 0; i < ((int) pow(2,k))/4; i++) { //runs through memory in blocks of 4
        if (mem[i*4] == ' ') {
            while ((i*4 + tempSize < pow(2, k)) && mem[i*4 + tempSize] == ' ') {
               tempSize++;
            }
            if (tempSize >= 4) { 
               tempSize -= tempSize%4; //rounds down to the nearest number divisible by 4
            }
            tempOffset = i*4;
            struct heapEntry *temp = new heapEntry(); 
            temp->offset = tempOffset;
            temp->blockSize = tempSize;
            myHeap[n] = *temp;
            n++;
            i = tempOffset + tempSize;
        }
    }
    for (int i = 0; i<n; i++) {
        maxHeapify(myHeap, i, n);
    }
    return;
}

void map(char *mem) {
    for (int ii = 0; ii < ((int) pow(2, k))/64; ii++) {
        char temp[64];
        int accum = 0;
        for (int jj = 0; jj < 64; jj++) {
            if (mem[ii*64 + jj] != '\0') {
                temp[jj] = mem[ii*64 + jj];
            } else {
                temp[jj] = '_';
            }
            accum += mem[ii*64 + jj];
        }
        printf("0x%05X;  %.*s;\n",  accum, 64, &temp);
    }
} 

int main() {
    int commandNum = 0;

    printf("Enter k: ");
    scanf("%d\n", &k);
    printf("Enter t: ");
    scanf("%d\n", &t);
    printf("Enter number of commands: ");
    scanf("%d\n", &commandNum);
    
    struct heapEntry *myHeap = (struct heapEntry*) malloc(((int) pow(2, k))*sizeof(struct heapEntry*));
    myHeap[0].blockSize = (int) pow(2, k);
    myHeap[0].offset = 0;
    n++;
    char *mem = (char*) malloc(((int) pow(2,k))*sizeof(char*));
    for (int ii = 0; ii < pow(2,k); ii++) {
        mem[ii] = '-';
    }

    struct symbolTableEntry *table = (struct symbolTableEntry*) malloc(t*sizeof(struct symbolTableEntry));
    for (int ii = 0;ii < t; ii++) {
        table[ii] = EMPTY;
    }


    for (int ii = 0; ii < commandNum; ii++) {
        std::string temp;
        std::getline(std::cin, temp);
        std::cout << temp << std::endl;
        instructionParser(temp, mem, myHeap, table);
    }
    free(mem);
    free(myHeap);
    return 0;
}
