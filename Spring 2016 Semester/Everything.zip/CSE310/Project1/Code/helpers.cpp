#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "defns.cc"

// Makes the algorithm easier to read at least. Returns TRUE if the elements passed need to be swapped.
bool sortByValue(struct team_stats &team1, struct team_stats &team2, std::string field, std::string order) {
    bool value;

        //STRINGS
    if (field.compare("team_name") == 0) {
        if (order.compare("incr") == 0)  {
            value = team1.team_name > team2.team_name;
        }
        else {
            value = team2.team_name > team1.team_name;
        }
    }
    if (field.compare("top_per_game") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.top_per_game > team2.top_per_game;
        }
        else {
            value = team2.top_per_game > team1.top_per_game;
        }
    }


        //FLOATS
    if (field.compare("pts_per_game") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.pts_per_game > team2.pts_per_game;
        }            
        else {
            value = team2.pts_per_game > team1.pts_per_game;
        }
    }

    if (field.compare("yds_per_game") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.yds_per_game > team2.yds_per_game;
        }            
        else {
            value = team2.yds_per_game > team1.yds_per_game;
        }
    }

    if (field.compare("yds_per_play") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.yds_per_play > team2.yds_per_play;
        }            
        else {
            value = team2.yds_per_play > team1.yds_per_play;
        }
    }

    if (field.compare("first_per_game") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.first_per_game > team2.first_per_game;
        }            
        else {
            value = team2.first_per_game > team1.first_per_game;
        }
    }



        //INTS
    if (field.compare("games") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.games > team2.games;
        }            
        else {
            value = team2.games > team1.games;
        }
    }

    if (field.compare("total_points") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.total_points > team2.total_points;
        }            
        else {
            value = team2.total_points > team1.total_points;
        }
    }

    if (field.compare("scrimmage_plays") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.scrimmage_plays > team2.scrimmage_plays;
        }            
        else {
            value = team2.scrimmage_plays > team1.scrimmage_plays;
        }
    }

    if (field.compare("third_md") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.third_md > team2.third_md;
        }            
        else {
            value = team2.third_md > team1.third_md;
        }
    }

    if (field.compare("third_att") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.third_att > team2.third_att;
        }            
        else {
            value = team2.third_att > team1.third_att;
        }
    }

    if (field.compare("third_pct") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.third_pct > team2.third_pct;
        }            
        else {
            value = team2.third_pct > team1.third_pct;
        }
    }

    if (field.compare("fourth_md") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.fourth_md > team2.fourth_md;
        }            
        else {
            value = team2.fourth_md > team1.fourth_md;
        }
    }

    if (field.compare("fourth_att") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.fourth_att > team2.fourth_att;
        }            
        else {
            value = team2.fourth_att > team1.fourth_att;
        }
    }

    if (field.compare("fourth_pct") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.fourth_pct > team2.fourth_pct;
        }            
        else {
            value = team2.fourth_pct > team1.fourth_pct;
        }
    }

    if (field.compare("penalties") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.penalties > team2.penalties;
        }            
        else {
            value = team2.penalties > team1.penalties;
        }
    }

    if (field.compare("pen_yds") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.pen_yds > team2.pen_yds;
        }            
        else {
            value = team2.pen_yds > team1.pen_yds;
        }
    }

    if (field.compare("fum") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.fum > team2.fum;
        }            
        else {
            value = team2.fum > team1.fum;
        }
    }

    if (field.compare("lost") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.lost > team2.lost;
        }            
        else {
            value = team2.lost > team1.lost;
        }
    }

    if (field.compare("to") == 0) {
        if (order.compare("incr") == 0) {
            value = team1.to > team2.to;
        }            
        else {
            value = team2.to > team1.to;
        }
    }

    return value;
}