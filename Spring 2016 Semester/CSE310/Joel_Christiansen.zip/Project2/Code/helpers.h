#ifndef HELPERS_H
#define HELPERS_H

void  instructionParser(std::string commandUnparsed, char *mem, struct heapEntry *myHeap, struct symbolTableEntry *table);

int probe(struct symbolTableEntry *table, const char* entry, int allocate, int t, size_t len);

void maxHeapify(struct heapEntry *myHeap, int i, int n);

#endif
