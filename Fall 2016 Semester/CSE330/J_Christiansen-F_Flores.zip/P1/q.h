#include <stdio.h>
#include <stdlib.h>
#include "tcb.h"

typedef struct Queue
{
    struct Queue* next;
    struct Queue* prev;
    TCB_t *payload;
} queue;

struct Queue* NewItem() {
    struct Queue *newItem = (struct Queue*) malloc(sizeof(struct Queue));
    return newItem;
}

struct Queue* newQueue() {
    struct Queue *head = NewItem();

    head->next = head;
    head->prev = head;
    return head;
}

void AddQueue(struct Queue *head, struct Queue *newItem) {
    newItem->prev = head->prev;
    head->prev = newItem;
    newItem->next = head;
    newItem->prev->next = newItem;
}

struct Queue* DelQueue(struct Queue *head) {
    if (head->next == head && head->prev == head) {
        printf("\nQueue Empty.\n");
        return NULL;
    } else {
        struct Queue *delItem = head->next;
        head->next = delItem->next;
        delItem->next->prev = head;
        return delItem;
    }
}
