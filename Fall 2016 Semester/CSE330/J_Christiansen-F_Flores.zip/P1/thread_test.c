// Joel Christiansen, Felipe Flores
#include "threads.h"

int fib = 0;
int fib1 = 1;

void func1() {
    int count = 0;
    while (count < 100) {
        printf("func1: %d\n", count);
        yield();
        count++;
    }
    yield();
}

void fibcount() {
    int count = 100;
    while (count > 0) {
        printf("fib: %d\n", fib); //this confused me to no end until I remembered int overflow is a thing
        int temp = fib;
        fib = fib1;
        fib1 = temp + fib;
        yield();
    }
    yield();
}


int main() {
    ReadyQ = newQueue();
    start_thread(func1);
    start_thread(fibcount);
    run();
    return 0;
}
     
